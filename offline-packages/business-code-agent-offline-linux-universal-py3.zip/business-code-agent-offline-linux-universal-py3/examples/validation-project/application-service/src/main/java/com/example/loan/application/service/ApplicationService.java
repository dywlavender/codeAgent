package com.example.loan.application.service;

import com.example.loan.application.domain.LoanApplication;
import com.example.loan.application.mapper.ApplicationMapper;

/** Creates the application snapshot consumed by later lifecycle stages. */
public class ApplicationService {
    private final ApplicationMapper applicationMapper;
    private final RepayTypePolicy repayTypePolicy;

    public ApplicationService(ApplicationMapper applicationMapper, RepayTypePolicy repayTypePolicy) {
        this.applicationMapper = applicationMapper;
        this.repayTypePolicy = repayTypePolicy;
    }

    public LoanApplication create(String customerId) {
        LoanApplication application = new LoanApplication();
        application.setCustomerId(customerId);
        application.setApplicationId("APP-" + customerId);
        application.setRepayType(repayTypePolicy.resolve(customerId));
        application.setStatus("APPROVED");
        applicationMapper.insert(application);
        return application;
    }

    public static class RepayTypePolicy {
        public String resolve(String customerId) {
            return customerId.startsWith("VIP-") ? "B" : "A";
        }
    }
}
