package com.example.loan.withdrawal.service;

import com.example.loan.application.domain.LoanApplication;
import com.example.loan.withdrawal.mapper.WithdrawalMapper;

/** Reuses the approved application snapshot instead of selecting a new repayment type. */
public class WithdrawalService {
    private final WithdrawalMapper withdrawalMapper;

    public WithdrawalService(WithdrawalMapper withdrawalMapper) {
        this.withdrawalMapper = withdrawalMapper;
    }

    public void withdraw(String applicationId) {
        LoanApplication application = withdrawalMapper.findApplication(applicationId);
        validateRepayType(application);
        withdrawalMapper.markWithdrawn(applicationId);
    }

    public void validateRepayType(LoanApplication application) {
        if (!"A".equals(application.getRepayType()) && !"B".equals(application.getRepayType())) {
            throw new IllegalArgumentException("repayType must be A or B when withdrawal starts");
        }
    }
}
