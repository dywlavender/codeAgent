package com.example.loan.withdrawal.api;

import com.example.loan.withdrawal.service.WithdrawalService;

/** HTTP adapter for the withdrawal flow. */
public class WithdrawalController {
    private final WithdrawalService withdrawalService;

    public WithdrawalController(WithdrawalService withdrawalService) {
        this.withdrawalService = withdrawalService;
    }

    public String withdraw(String applicationId) {
        withdrawalService.withdraw(applicationId);
        return "ACCEPTED";
    }
}
