package com.example.loan.settlement;

import com.example.loan.settlement.mapper.SettlementMapper;
import java.util.List;
import org.springframework.scheduling.annotation.Scheduled;

/** Scheduled flow that settles approved applications after withdrawal. */
public class SettlementJob {
    private final SettlementMapper settlementMapper;

    public SettlementJob(SettlementMapper settlementMapper) {
        this.settlementMapper = settlementMapper;
    }

    /** Runs every five minutes and only handles applications ready for settlement. */
    @Scheduled(fixedDelay = 300000)
    public void syncApprovedApplications() {
        List<String> applicationIds = settlementMapper.findApprovedApplications();
        for (String applicationId : applicationIds) {
            settlementMapper.markSettled(applicationId);
        }
    }
}
