package com.example.loan.settlement.mapper;

import java.util.List;

public interface SettlementMapper {
    List<String> findApprovedApplications();

    void markSettled(String applicationId);
}
