package com.example.loan.withdrawal.mapper;

import com.example.loan.application.domain.LoanApplication;

public interface WithdrawalMapper {
    LoanApplication findApplication(String applicationId);

    void markWithdrawn(String applicationId);
}
