package com.example.loan.application.api;

import com.example.loan.application.service.ApplicationService;

/** HTTP adapter for the application creation flow. */
public class ApplicationController {
    private final ApplicationService applicationService;

    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    public LoanApplicationResponse create(CreateApplicationRequest request) {
        return LoanApplicationResponse.from(applicationService.create(request.customerId()));
    }

    public record CreateApplicationRequest(String customerId) {
    }

    public record LoanApplicationResponse(String applicationId, String repayType) {
        static LoanApplicationResponse from(com.example.loan.application.domain.LoanApplication application) {
            return new LoanApplicationResponse(application.getApplicationId(), application.getRepayType());
        }
    }
}
