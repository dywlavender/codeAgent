package com.example.loan.application.mapper;

import com.example.loan.application.domain.LoanApplication;

public interface ApplicationMapper {
    void insert(LoanApplication application);
}
