# Loan Lifecycle Validation Project

这是 Business Code Intelligence Agent 的独立验证项目，不是可上线的业务系统。
它用一个很小的贷款申请生命周期，固定制造可验证的代码事实、业务解释、需求依据和 Git 变更。

## 验证目标

验证以下链路是否成立：

```text
Java / MyBatis 源码
        ↓
代码事实（字段写入、读取、校验、表列读写、定时任务）
        ↓
人工补充的功能知识 + 需求依据
        ↓
Knowledge Update Agent 生成待审核变更
        ↓
人工确认后发布
        ↓
Query Agent 用 Evidence 回答问题
```

## 项目故事

贷款申请在申请阶段确定 `repayType`。提款阶段不能重新选择还款方式，必须读取申请记录中的值并校验。清算任务只处理已批准的申请，并把结算状态更新为 `SETTLED`。

`v1.0-rule-a-only` 的初始规则只允许 `repayType=A`；当前 `main` 已演进为普通客户使用 `A`、VIP 客户允许使用 `B`。

## 目录

- `application-service`：创建申请并写入 `repayType`
- `withdrawal-service`：读取申请并校验 `repayType`
- `settlement-job`：定时扫描已批准申请并更新结算状态
- `docs/requirements`：可导入的需求文档
- `docs/business`：提交给管理员的人工业务说明
- `docs/validation-cases.json`：固定验收问题和预期证据

## 用当前工作台验证

在产品仓库根目录执行。以下命令不会修改本目录中的源码。

项目配置已经写入产品根目录的 `project.config.json`，包括数据库 `.data/validation-project.db` 和端口 `8083`，因此可以直接启动：

```bash
./start-mac.sh
```

Windows：

```bat
start-windows.bat
```

启动器会从配置文件自动同步本项目，不需要再传 `--repository`、`--repository-id`、`--database` 或 `--port`。如需临时覆盖，再显式传入对应参数。

### 1. 建立空库并索引源码

```bash
business-code-agent init-db --db .data/validation-project.db
business-code-agent ingest-repo examples/validation-project --db .data/validation-project.db --repository-id validation-project
```

也可以先查看字段生命周期候选：

```bash
business-code-agent analyze-repo examples/validation-project --db .data/validation-project.db --repository-id validation-project --json
business-code-agent explain repayType --db .data/validation-project.db --json
```

### 2. 导入需求依据

```bash
business-code-agent requirement-import \
  examples/validation-project/docs/requirements/REQ-VAL-001.md \
  --id REQ-VAL-001 --db .data/validation-project.db
```

需求中的规则使用项目符号段落，而不是 `1.`、`2.` 编号标题；这样可以避免被当前的 Markdown 标题识别规则误判。

### 3. 提交并审核功能知识

在管理员页面的“知识治理”中提交下面的人工说明：

```text
申请还款方式与提款校验：申请创建时由产品策略确定 repayType 并持久化；提款是同一申请生命周期的后续阶段，必须读取并校验该值；清算定时任务只处理已批准且尚未结算的申请并更新结算状态。当前代码规则是普通客户使用 repayType=A，VIP 客户允许使用 repayType=B。
```

关联证据时选择 `ApplicationService.create`、`WithdrawalService.validateRepayType`、`SettlementJob.syncApprovedApplications` 和对应的 MyBatis Statement。

### 4. 固定问题

建议至少验证：

1. `repayType` 在哪里生成、读取和校验？
2. 为什么提款阶段不能重新生成 `repayType`？
3. 申请、提款、清算三个流程如何通过数据关联？
4. 清算任务什么时候运行，处理哪些申请？
5. `repay_type` 在哪张表读取和写入？
6. 代码中是否存在申请服务直接调用提款服务？

预期回答必须引用代码 Evidence；没有需求或人工说明时，只能回答“当前实现”，不能把代码推测成业务原因。

## Git 变更验证

本目录是独立 Git 仓库，包含三个有意设计的状态：

```bash
git log --oneline --all
```

- `v1.0-rule-a-only`：初始规则，只允许 `A`
- `v1.1-allow-b`：需求、策略和校验规则改为允许 `A`、`B`
- `v1.2-batch-scope`：清算任务进一步排除已经结算的申请，只扫描 `APPROVED` 且 `settlement_status IS NULL` 的记录

使用方式：

1. 在 `v1.0-rule-a-only` 状态索引并导入需求、业务知识。
2. 切换到 `v1.1-allow-b`，再次执行 `ingest-repo`。
3. 查看代码变更和知识更新 Agent 产生的待审核建议，确认旧知识没有被自动覆盖。
4. 切换到 `v1.2-batch-scope`，验证定时任务范围的变化是否形成新的证据和更新建议。

验证完成后回到最新状态：

```bash
git switch main
```

## 范围说明

这个项目故意不接真实数据库、不启动 Spring 服务，也不引入外部依赖。它的目标是测试知识链路，而不是测试业务系统运行性能。后续使用真实开源项目时，再补充编译、运行和跨服务部署验证。
